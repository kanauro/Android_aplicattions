package com.example.profilometer

data class LocationDetails(
    var azimut:Float,
    var lat:Double,
    var long:Double,
    var elevation:Double,
    var distance:Float,
    var speedCurrent: Float,
    var speedMax: Float,
    var speedAver: Double,
    var ascent: Double,
    var descent: Double,
    var ascentDescentCur: Double
)
