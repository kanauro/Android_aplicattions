package com.example.profilometer

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentManager

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.example.profilometer.databinding.ActivityMapsBinding
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationListener
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.*
import com.google.android.material.bottomsheet.BottomSheetBehavior

class MapsActivity : AppCompatActivity(), OnMapReadyCallback,
    GoogleApiClient.ConnectionCallbacks,
    GoogleApiClient.OnConnectionFailedListener,
    LocationListener {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var mGoogleApiClient: GoogleApiClient
    private var running = false
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var iconPerson: BitmapDescriptor
    private lateinit var polylineOptions: PolylineOptions
    private lateinit var fragment: MainFragment
    private var lastLoc: Location? = null
    private var polylines = mutableListOf<PolylineOptions>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkPermissions()
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        fragment = MainFragment.newInstance()
        if (savedInstanceState == null){
            supportFragmentManager.beginTransaction()
                .replace(R.id.containerLocationInfo, fragment)
                .commitNow()
        }
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        mGoogleApiClient = GoogleApiClient.Builder(this)
            .addApi(LocationServices.API)
            .addConnectionCallbacks(this)
            .addOnConnectionFailedListener(this)
            .build()

        polylineOptions = PolylineOptions()
        iconPerson = BitmapDescriptorFactory.fromResource(R.drawable.person)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @SuppressLint("MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera
        fusedLocationProviderClient = FusedLocationProviderClient(this)
        val mLastLoc = fusedLocationProviderClient.lastLocation
        mLastLoc.addOnCompleteListener { it ->
            run {
                val mLoc = LatLng(it.result.latitude, it.result.longitude)
                var markerOptions = MarkerOptions()
                    .position(mLoc)
                    .title("Marker at user's location")
                    .icon(iconPerson)
                mMap.addMarker(markerOptions)
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mLoc, 17f))
            }
        }

    }

    private fun checkPermissions(){
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M){
            if (ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION),
                    0)

            }
        }
    }

    override fun onStart() {
        super.onStart()
        mGoogleApiClient.connect()
    }
    override fun onPause() {
        super.onPause()
        if (mGoogleApiClient.isConnected){
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this)
            mGoogleApiClient.disconnect()
        }
    }

    @SuppressLint("MissingPermission")
    override fun onConnected(p0: Bundle?) {
        val mLocationRequest = LocationRequest()
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .setInterval((1 * 1000).toLong())
            .setFastestInterval((1 * 1000).toLong())
            .setSmallestDisplacement(0f)
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,mLocationRequest,this@MapsActivity)
    }

    override fun onConnectionSuspended(p0: Int) {
        TODO("Not yet implemented")
    }

    override fun onConnectionFailed(p0: ConnectionResult) {
        TODO("Not yet implemented")
    }

    override fun onLocationChanged(p0: Location) {
        if (lastLoc == null) lastLoc = p0
        val latlng = LatLng(p0.latitude, p0.longitude)
        if (fragment.running) polylineOptions.add(latlng)
        mMap.clear()
        var markerOptions = MarkerOptions()
            .position(latlng)
            .title("Marker at user's location")
            .icon(iconPerson)
        mMap.addMarker(markerOptions)
        for (option in polylines){
            mMap.addPolyline(option)
        }
        mMap.addPolyline(polylineOptions)
    }

    fun updatePolyline(){
        polylines.add(polylineOptions)
        polylineOptions = PolylineOptions()
    }

    fun resetPolyline(){
        polylines.clear()
        polylineOptions = PolylineOptions()
    }
}