package com.example.profilometer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.lifecycle.LiveData
import com.google.android.gms.location.*
import com.google.android.gms.location.LocationServices.getFusedLocationProviderClient

class LocationLiveData(context: Context): LiveData<LocationDetails>() {
    private var mContext = context
    private var running = false

    private var fusedLocationClient = getFusedLocationProviderClient(mContext)

    private var allDistance: Float = 0f
    private var speedMax: Float = 0f
    private var startTime: Double = System.currentTimeMillis().toDouble() / 1000

    private var startAltitude:Double? = null
    private var ascent:Double = 0.0
    private var descent:Double = 0.0

    private  var prevLocation: Location? = null

    override fun onInactive() {
        super.onInactive()
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    @SuppressLint("MissingPermission")
    override fun onActive() {
        super.onActive()
        fusedLocationClient.lastLocation.addOnSuccessListener {
            location: Location -> location.also {
            if (running) setLocationData(it)
            }
        }
        startLocationUpdates()
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null)
    }

    private val locationCallback = object : LocationCallback(){
        override fun onLocationResult(locationResult: LocationResult) {
            super.onLocationResult(locationResult)
            if (running){
                for (location in locationResult.locations) {
                    setLocationData(location)
                }
            }
        }
    }

    fun setRunning(run: Boolean){
        running = run
    }
    private fun setLocationData(location: Location?){
        if (prevLocation == null) prevLocation = location!!
        else{
            allDistance += prevLocation!!.distanceTo(location)
            prevLocation = location
        }
        var speed = location!!.speed
        if (speed > speedMax) speedMax = speed

        var actAsDescent = 0.0

        if (startAltitude == null){
            startAltitude = location.altitude
        } else {
            val difference = location.altitude - startAltitude!!
            if (difference > ascent) ascent = difference
            else if (difference < descent) descent = difference

            actAsDescent = difference * 100 / startAltitude!!
        }
        val timeCurrent = System.currentTimeMillis().toDouble() / 1000
        value = LocationDetails(
            azimut = location.bearing,
            lat = location.latitude,
            long = location.longitude,
            elevation = location.altitude,
            allDistance / 1000,
            speedCurrent = speed,
            speedMax = speedMax,
            speedAver = (allDistance / (timeCurrent - startTime) * 60 / 1000),
            ascent = ascent,
            descent = descent,
            ascentDescentCur = actAsDescent
            )
    }
    companion object{
        val locationRequest: LocationRequest = LocationRequest.create().apply {
            interval = 10000
            fastestInterval = 1000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY

        }
    }
}