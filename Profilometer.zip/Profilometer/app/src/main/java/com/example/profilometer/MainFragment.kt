package com.example.profilometer

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.os.SystemClock
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Chronometer
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlinx.android.synthetic.main.main_fragment.*
import java.text.DecimalFormat

class MainFragment : Fragment() {

    var running = false
    private var pauseOffset: Long = 0

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var locationViewModel: LocationViewModel


    private lateinit var chronometer: Chronometer
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.main_fragment, container, false)
    }

    @SuppressLint("SetTextI18n")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        locationViewModel = ViewModelProvider(this).get(LocationViewModel::class.java)
        chronometer = m_chronometer
        btnStart = btn_start
        btnStop = btn_stop
        btnStart.setOnClickListener {
            if (!running) {
                startChronometer()
                running = true
                locationViewModel.getLocationLineData().setRunning(running)
                btnStop.text = "stop"
            }
        }
        btnStop.setOnClickListener {
            val mapsActivity = activity as MapsActivity
            if(running){
                stopChronometer()
                running = false
                locationViewModel.getLocationLineData().setRunning(running)
                btnStop.text = "finish"
                mapsActivity.updatePolyline()
            } else {
                resetData()
                finishChronometer()
                mapsActivity.resetPolyline()
            }
        }
        prepRequestLocationUpdates()
    }

    private fun finishChronometer() {
        chronometer.base = SystemClock.elapsedRealtime()
        pauseOffset = 0
    }

    @SuppressLint("SetTextI18n")
    private fun resetData() {
        ascent.text = "--"
        current_ascent_descent.text = "0%"
        azimut.text = "--"
        descent.text = "--"
        distance.text = "0 km"
        elevation.text = "--"
        latitude.text = "--"
        longitude.text = "--"
        average_speed.text = "0 km/h"
        current_speed.text = "0 km/h"
        maximum_speed.text = "0 km/h"
    }

    private fun stopChronometer() {
        chronometer.stop()
        pauseOffset = SystemClock.elapsedRealtime() - chronometer.base
    }

    private fun startChronometer() {
        chronometer.base = SystemClock.elapsedRealtime() - pauseOffset
        chronometer.start()
    }

    @SuppressLint("SetTextI18n")
    private fun requestLocationUpdates(){
        locationViewModel = ViewModelProvider(this)[LocationViewModel::class.java]
        locationViewModel.getLocationLineData().observe(viewLifecycleOwner, Observer {
            ascent.text = DecimalFormat("##.##m").format(it.ascent).toString()
            current_ascent_descent.text = DecimalFormat("##.##").format(it.ascentDescentCur).toString() + "%"
            azimut.text = it.azimut.toString()
            descent.text = DecimalFormat("##.##m").format(it.descent).toString()
            distance.text = DecimalFormat("##.##km").format(it.distance).toString()
            elevation.text = DecimalFormat("##.##").format(it.elevation).toString()
            latitude.text = it.lat.toString()
            longitude.text = it.long.toString()
            average_speed.text = DecimalFormat("##.##km/h").format(it.speedAver).toString()
            current_speed.text = DecimalFormat("##.##km/h").format(it.speedCurrent).toString()
            maximum_speed.text = DecimalFormat("##.##km/h").format(it.speedMax).toString()
        })
    }

    private fun prepRequestLocationUpdates() {
        if (ContextCompat.checkSelfPermission(requireContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION),
                0)
        } else {
            requestLocationUpdates()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode){
            0 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    requestLocationUpdates()
                }
            }
        }
    }
}