package com.example.profilometer

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel

class LocationViewModel(application: Application): AndroidViewModel(application) {
    private val locationLiveData =  LocationLiveData(application)

    fun getLocationLineData() =  locationLiveData


}