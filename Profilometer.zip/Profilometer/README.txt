Profilometer.
Made through MVVM.
Feature:
At the top is a fragment of the map. It is associated with a fragment with information. During the walk, the completed route will be displayed.
All information from the GPS will be displayed at the bottom.
Functional:
When you click "start", the information from the GPS will begin to be transmitted, and the route will be drawn on the map.
When you click stop, the route is interrupted and stops drawing further, but the previous one remains. The information also stops.
The stop button changes to the finish button.
When you click on the finish line, all tracks disappear, and the information is reset to zero.