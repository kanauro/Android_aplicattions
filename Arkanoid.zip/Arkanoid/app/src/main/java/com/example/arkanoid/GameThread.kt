package com.example.arkanoid

import android.graphics.Canvas
import android.os.Looper

class GameThread(val gamePanel: GamePanel) : Thread() {
    var running = true

    override fun run() {
        val surfaceHolder = gamePanel.holder
        val ball = gamePanel.ball
        while (running){
            var canvas: Canvas? = null
            try {
                canvas = surfaceHolder.lockCanvas()
                if (canvas == null){
                    break
                }
                synchronized(surfaceHolder){
                    ball.update(canvas, gamePanel.board, gamePanel.bricks)
                    ball.speedUp(0.001)
                    if (gamePanel.gameOver()) {
                        this.running = false
                    }
                    gamePanel.show(canvas)
                    gamePanel.bricks.forEach {
                        it.draw(canvas)
                    }
                    gamePanel.bricks = gamePanel.bricks.filter { !it.destroyed }.toMutableList()
                }
            } finally {
                if (canvas != null){
                    surfaceHolder.unlockCanvasAndPost(canvas)
                }
            }
        }
        Looper.prepare()
        //Toast.makeText(gamePanel.context, "Game Over", Toast.LENGTH_LONG).show()
    }
}