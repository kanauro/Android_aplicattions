package com.example.arkanoid

class Direction {
}