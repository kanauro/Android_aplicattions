package com.example.arkanoid

import android.annotation.SuppressLint
import android.app.ProgressDialog.show
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory.decodeResource
import android.graphics.Canvas
import android.graphics.Color
import android.util.Log
import android.view.*
import android.widget.Toast
import java.io.IOException
import kotlin.random.Random


@SuppressLint("NewApi")
class GamePanel(context: Context): SurfaceView(context) , SurfaceHolder.Callback {
    var thread: GameThread
    lateinit var ball: Ball
    lateinit var board: Board
    var bricks: MutableList<Brick> = mutableListOf()
    var actDx: Float? = null
    var actDy: Float? = null
    private var screenX = 0
    private var screenY = 0

    var brickImages = mutableListOf<Bitmap>()
    lateinit var boardImage: Bitmap
    lateinit var ballImage: Bitmap
    init {
        holder.addCallback(this)
        isFocusable = true
        thread = GameThread(this)
    }

    override fun surfaceCreated(p0: SurfaceHolder) {
        screenX = width
        screenY = height
        boardImage = Bitmap.createScaledBitmap(decodeResource(resources, R.drawable.board), screenX/6, screenY/30, true)
        ballImage = Bitmap.createScaledBitmap(decodeResource(resources, R.drawable.ball), screenX/30, screenX/30, true)
        createBrickImages()

        board = Board(boardImage, screenX/2f, screenY-100f)
        ball = Ball(ballImage, board.posX, board.posY- 60, Random.nextInt(45, 135))
        createBricksLevel("lvl1.txt")
        thread.start()

    }

    override fun surfaceChanged(p0: SurfaceHolder, p1: Int, p2: Int, p3: Int) {

    }

    override fun surfaceDestroyed(p0: SurfaceHolder) {
        var retry = true
        thread.running = false
        while (retry) {
            try {
                thread.join()
                retry = false
            } catch (e: InterruptedException) {
            }
        }
    }
    fun createBrickImages(){
        val brickW = screenX/10
        val brickH = screenY/30
        with(brickImages) {
            add(Bitmap.createScaledBitmap(decodeResource(
                resources,
                R.drawable.brick1
            ), brickW, brickH, true))
            add(Bitmap.createScaledBitmap(decodeResource(
                resources,
                R.drawable.brick2
            ),brickW, brickH, true))
        }
    }
    fun createBricksLevel(filename: String){
        try {
            val reader = context.assets.open(filename).bufferedReader()
            var i = 0
            var line = reader.readLine()
            while (line != null){
                val lineArr = line.split(" ")
                var j = 0
                lineArr.forEach {
                    if (it == "$"){
                        val img = brickImages[i % brickImages.size]
                        val posX = j*img.width.toFloat()
                        val posY = i*img.height.toFloat()
                        Log.d("add brick", "$posX | $posY | ${img.height}")
                        bricks.add(Brick(img,posX, posY))
                    }
                    j += 1
                }
                i += 1
                line = reader.readLine()
            }
        } catch (ex : IOException){
            ex.printStackTrace()
        }
    }
    fun show(canvas: Canvas?){
        if (canvas != null){
            canvas.drawColor(Color.BLACK)
            ball.draw(canvas)
            board.draw(canvas)
        }
    }
    fun gameOver():Boolean{
        val result = ball.posY < ball.posY || bricks.isEmpty()
        if (result){
            //Toast.makeText(context, "Game Over!", Toast.LENGTH_LONG).show()
        }
        return ball.posY > board.posY || bricks.isEmpty()
    }
    fun startTouch(x: Float, y: Float){
        if (x >= board.posX-board.width/2 &&
            x <= board.posX+board.width/2 &&
            y >= board.posY-board.height/2 &&
            y <= board.posY+board.height/2)
            {
                actDx = board.posX-x
                actDy = board.posY-y
        }
    }
    fun moveTouch(x: Float){
        if (actDx != null && x + actDx!! - board.width/2 >= 0 &&  x + actDx!! + board.width/2 <= screenX){
            board.setPos(x + actDx!!, board.posY)
        }
    }
    fun upTouch(){
        actDx = null
        actDy = null
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        val x = event!!.x
        val y = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startTouch(x, y)
            }
            MotionEvent.ACTION_MOVE -> {
                moveTouch(x)
            }
            MotionEvent.ACTION_UP -> {
                upTouch()
            }
        }
        return true
    }
}
