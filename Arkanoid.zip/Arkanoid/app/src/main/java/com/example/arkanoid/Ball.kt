package com.example.arkanoid

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.icu.text.DateTimePatternGenerator
import android.util.Log
import kotlin.math.sqrt

class Ball (var image: Bitmap, var posX: Float, var posY: Float, var alpha: Int) {
    var speed = 5.0
    var r = image.width/2
    fun update(canvas: Canvas, board: Board, bricks: MutableList<Brick>) {
        SolveCollisionWithBoard(board)
        if (posX-r <= 0 || posX + r >= canvas.width){
            if (alpha < 180) alpha = 180 - alpha
            else alpha = 360 - alpha + 180
        }
        if (posY - r <= 0) alpha = 360 - alpha
        Log.d("ungle", "${alpha}")
        bricks.forEach destroy@{
            if (! it.destroyed){
                if (CheckCollisionWithBrick(it)){
                    if ((posY < it.posY && alpha in 181..359)  || (posY > it.posY + it.height && alpha in 1..179)) alpha = 360 - alpha
                    else if (posX < it.posX && ((alpha in 1..89) || (alpha in 271..359))){
                        if (alpha < 180) alpha = 180 - alpha
                        else alpha = 360 - alpha + 180
                    }
                    else if (posX > it.posX && ((alpha in 91..279)) ){
                        if (alpha < 180) alpha = 180 - alpha
                        else alpha = 360 - alpha + 180
                    }
                    it.destroyed = true
                    return@destroy
                }
            }
        }
        posX += (speed * Math.cos(alpha * (Math.PI / 180))).toFloat()
        posY -= (speed * Math.sin(alpha * (Math.PI / 180))).toFloat()
    }
    fun CheckCollisionWithBrick(brick: Brick): Boolean{
        var testX = posX
        var testY = posY
        if (posX < brick.posX) testX = brick.posX        // left edge
        else if (posX > brick.posX+brick.width) testX = brick.posX+brick.width     // right edge
        if (posY < brick.posY)  testY = brick.posY;        // top edge
        else if (posY > brick.posY + brick.height) testY = brick.posY + brick.height     // bottom edge
        val distX: Float = posX - testX
        val distY: Float = posY - testY
        val distance: Float = sqrt(distX * distX + distY * distY)

        return distance <= r
    }
    fun SolveCollisionWithBoard(board: Board){
        if (posX >= (board.posX-board.width/2) &&
            posX <= (board.posX+board.width/2) &&
            posY >= board.posY-board.height/2) alpha = 360 - alpha
    }
    fun draw(canvas: Canvas) {
        canvas.drawBitmap(image, (posX-r), (posY-r), null)
    }
    fun speedUp(value:Double){
        speed += value
    }
}

