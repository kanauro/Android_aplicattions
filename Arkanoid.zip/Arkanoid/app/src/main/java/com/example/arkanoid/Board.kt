package com.example.arkanoid

import android.graphics.Bitmap
import android.graphics.Canvas

class Board (var image: Bitmap, var posX: Float, var posY: Float){
    var height = image.height
    var width = image.width
    fun draw(canvas: Canvas){
        canvas.drawBitmap(image, (posX-image.width / 2), (posY-image.height / 2), null)
    }
    fun setPos(x:Float, y:Float){
        posX = x
        posY = y
    }
}