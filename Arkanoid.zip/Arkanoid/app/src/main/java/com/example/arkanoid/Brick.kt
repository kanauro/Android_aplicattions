package com.example.arkanoid

import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.Log

class Brick(var image: Bitmap, var posX: Float, var posY: Float) {
    var destroyed: Boolean = false
    var height = image.height
    var width = image.width
    fun draw(canvas: Canvas){
        if (!destroyed) canvas.drawBitmap(image, posX, posY, null)
    }
    fun update(ball: Ball){
    }
    fun isCollisionWithBall(ball: Ball): Boolean{
        if (ball.posX + ball.r < posX || ball.posX - ball.r > posX+width) return false
        if (ball.posY + ball.r < posY || ball.posY - ball.r > posY+height) return false
        var testX = ball.posX
        var testY = ball.posY
        if (ball.posX < posX) testX = posX
        else if (ball.posX >= posX + height) testX = posX + width
        if (ball.posY < posY) testY = posY
        else if (ball.posY >= posY + width) testY = posY + height

        val distX = ball.posX - testX
        val distY = ball.posY - testY
        val distance = Math.sqrt(Math.pow(distX.toDouble(), 2.0) + Math.pow(distY.toDouble(), 2.0))
        return distance <= ball.r

    }
}