package com.example.arkanoid

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint

class Playground (image: Bitmap, height: Int, width: Int){
    var img = image
    init {
        img.height = height
        img.width = width
    }
    fun draw(canvas: Canvas, paint: Paint){
        canvas.drawBitmap(img, 0f, 0f, paint)
    }
    fun resize(height: Int, width: Int){
        img.height = height
        img.width = width
    }
}