Klon hry Arkanoid.
Každý prvok v hre je samostatný objekt (lopta, doska, blok)
Adaptácia hry prebieha cez SurfaceView.
Vytvorí sa jedna úroveň (manuálne, má reprezentáciu textového súboru, potom môžete úrovne ľahko doplniť)
Ak sú všetky bloky rozbité alebo lopta spadne cez hraciu plochu, hra sa končí.
Smer loptičky je daný uhlom, smer sa vypočíta pomocou funkcie sin a cos.
Funkcie na inicializáciu objektov, ich kreslenie a sledovanie pohybov sú implementované v triede GamePanel. 

***
Ak chcete rýchlo určiť, ktorá aplikácia je moja -
ikona tejto hry (a všetkých nasledujúcich) ikona s mojou prezývkou Kanaero.