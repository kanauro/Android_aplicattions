package com.example.calculator.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.example.calculator.R
import com.example.calculator.BR.myCalculatorViewModel
import com.example.calculator.databinding.DecCalculatorFragmentBinding

class DecCalculatorFragment : Fragment() {

    companion object {
        fun newInstance() = DecCalculatorFragment()
    }

    private lateinit var viewModel: CalculatorViewModel
    private lateinit var binding: DecCalculatorFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        viewModel = ViewModelProvider(this).get(CalculatorViewModel::class.java)
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.dec_calculator_fragment,
            container,
            false
        )
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(CalculatorViewModel::class.java)
        viewModel.setHexMode(false)
        binding.setVariable(myCalculatorViewModel, viewModel)
    }

}