package com.example.calculator.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.example.calculator.R
import com.example.calculator.databinding.HexCalculatorFragmentBinding
import com.example.calculator.BR.myCalculatorViewModel

class HexCalculatorFragment : Fragment() {

    companion object {
        fun newInstance() = HexCalculatorFragment()
    }

    private lateinit var viewModel: CalculatorViewModel
    private lateinit var binding: HexCalculatorFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        viewModel = ViewModelProvider(this).get(CalculatorViewModel::class.java)
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.hex_calculator_fragment,
            container,
            false
        )
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(CalculatorViewModel::class.java)
        viewModel.setHexMode(true)
        binding.setVariable(myCalculatorViewModel, viewModel)
    }

}