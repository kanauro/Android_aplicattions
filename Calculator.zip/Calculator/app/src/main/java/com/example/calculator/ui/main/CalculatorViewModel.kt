package com.example.calculator.ui.main

import android.util.Log
import android.view.View
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import java.util.*

class CalculatorViewModel : ViewModel() {
    private var args: MutableList<Int> = mutableListOf()
    private var ops: MutableList<Char> = mutableListOf()
    var input: MutableLiveData<String> = MutableLiveData()
    var output: MutableLiveData<String> = MutableLiveData()
    var arg: String = ""
    var isHexVisible: MutableLiveData<Int> = MutableLiveData()

    init {
        input.value = ""
        output.value = ""
        isHexVisible.value = View.VISIBLE
    }

    fun setHexMode(isHex : Boolean){
        isHexVisible.value = if (isHex) View.VISIBLE else View.GONE
    }
    fun pressBtn(ch: Char){
        when (ch){
            in '0'..'9', in 'A'..'F' -> {
                arg += ch
                input.value += ch
                output.value += ch
            }
            '=' -> {
                if (arg != ""){
                    if (isHexVisible.value == View.VISIBLE) args.add(arg.toInt(16))
                    else args.add(arg.toInt())
                    arg = ""
                }
                val res = eval()
                input.value = res
                output.value = res
                if (isHexVisible.value == View.VISIBLE) args.add(res.toInt(16))
                else args.add(res.toInt())
            }
            'c' -> {
                input.value = ""
                arg = ""
                output.value = ""
                args.clear()
            }
            else -> {
                if (arg != ""){
                    if (isHexVisible.value == View.VISIBLE) args.add(arg.toInt(16))
                    else args.add(arg.toInt())
                    arg = ""
                }
                if (output.value!! != "" && output.value!![0] !in listOf('+', '-', '/', '*')){
                    ops.add(ch)
                    input.value += ch
                }
                output.value = ""
            }

        }
    }
    fun eval(): String{
        val prior: Map<Char, Int> = mapOf(Pair('+', 1), Pair('-', 1), Pair('*', 2), Pair('/', 2))
        if (args.size == 0) return ""
        if (args.size == 1){
            val res = args[0]
            args.clear()
            ops.clear()
            return res.toString()
        }
        var opCur: Int = 0
        while (ops.size != 0){
            opCur = 0
            Log.d("res", args.toString())
            (1 until ops.size).forEach{
                i ->
                opCur = if (prior[ops[i]]!! > prior[ops[opCur]]!!) i else opCur
            }
            args[opCur] = when(ops[opCur]){
                '+' -> args[opCur] + args[opCur+1]
                '-' -> args[opCur] - args[opCur+1]
                '*' -> args[opCur] * args[opCur+1]
                '/' -> args[opCur] / args[opCur+1]
                else -> args[opCur]
            }
            ops.removeAt(opCur)
        }
        val res = args[0]
        args.clear()
        if (isHexVisible.value == View.VISIBLE) return res.toString(16).uppercase()
        return res.toString()
    }
}
