package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.calculator.R
import com.example.calculator.ui.main.DecCalculatorFragment
import com.example.calculator.ui.main.HexCalculatorFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.containerDec, DecCalculatorFragment.newInstance())
                .replace(R.id.containerHex, HexCalculatorFragment.newInstance())
                .commitNow()
        }
    }
}