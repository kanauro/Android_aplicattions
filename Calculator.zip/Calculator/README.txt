Aplikácia Kalkulačka.
Ikona kalkulačky. Názov je „Calculator“.
Vyrobené v dvoch rôznych fragmentoch s jedným spoločným modelom.
Existujú dve polia, jedno pre celý výraz, druhé pre aktuálny argument a nakoniec pre výsledok.
Základné operácie sú naprogramované, je tu tlačidlo "vymazať"
Zohľadňujú sa aj priority operácie.  V časti 16. systéme sa argumenty chrania naspamäť v 10. systéme, 
vykonajú sa všetky operácie a potom sa výsledok prevedie do 16. systému. 