package com.example.googletestmaps2

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Chronometer
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.example.googletestmaps2.databinding.ActivityMapsBinding
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.*
import com.google.android.gms.location.LocationServices.FusedLocationApi


import com.google.android.gms.maps.model.*

const val TAG = "WHATSUP"

@Suppress("DEPRECATION")
class MapsActivity : AppCompatActivity(),
    OnMapReadyCallback,
    GoogleApiClient.ConnectionCallbacks,
    GoogleApiClient.OnConnectionFailedListener,
    LocationListener{

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var mGoogleApiClient: GoogleApiClient
    private lateinit var chronometer: Chronometer
    private lateinit var btnAdd: Button
    private lateinit var iconPerson: BitmapDescriptor
    private lateinit var iconPause: BitmapDescriptor
    private lateinit var iconActiveCheckPoint: BitmapDescriptor
    private lateinit var iconPassiveCheckPoint: BitmapDescriptor
    private var running = false
    private var modeAddCheckPoint = false
    private var pauseOffset: Long = 0
    private var checkPoints: MutableList<LatLng> =
        mutableListOf()

    private var lastPausePosition: LatLng? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkPermissions()
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        mGoogleApiClient = GoogleApiClient.Builder(this)
            .addApi(LocationServices.API)
            .addConnectionCallbacks(this)
            .addOnConnectionFailedListener(this)
            .build()

        iconPerson = BitmapDescriptorFactory.fromResource(R.drawable.person)
        iconPause = BitmapDescriptorFactory.fromResource(R.drawable.pause_icon)
        iconActiveCheckPoint = BitmapDescriptorFactory.fromResource(R.drawable.active_flag)
        iconPassiveCheckPoint = BitmapDescriptorFactory.fromResource(R.drawable.passive_flag)
        chronometer = findViewById(R.id.m_chronometer)
        btnAdd = findViewById(R.id.btn_add)
        btnAdd.setOnClickListener {
            addCheckPoint(it)
        }
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    private fun checkPermissions(){
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M){
            if (ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION),
                    0)

            }
        }
    }
    @SuppressLint("MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {

        mMap = googleMap
        // Add a marker in Sydney and move the camera
        val mLastLoc = getFusedLocationProviderClient(this).lastLocation
        mLastLoc.addOnCompleteListener { it ->
            val mLocation = LatLng(it.result.latitude, it.result.longitude)
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mLocation, 17f))
            mMap.setOnMapClickListener {
                if (modeAddCheckPoint){
                    checkPoints.add(it)
                    btnAdd.visibility = View.VISIBLE
                    Toast.makeText(this, "Done!", Toast.LENGTH_LONG).show()
                    updateCheckPoints(mLocation)
                }
            }
            updateCheckPoints(mLocation) }
    }
    @SuppressLint("MissingPermission")
    override fun onConnected(p0: Bundle?) {
        Log.d(TAG, "onConnected")
        val mLocationRequest = LocationRequest()
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .setInterval((1 * 1000).toLong())
            .setFastestInterval((1 * 1000).toLong())
            .setSmallestDisplacement(0f)

        FusedLocationApi.requestLocationUpdates(mGoogleApiClient,mLocationRequest,this@MapsActivity)
    }

    override fun onStart() {
        super.onStart()
        mGoogleApiClient.connect()

    }

    override fun onPause() {
        super.onPause()
        if (mGoogleApiClient.isConnected){
            FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this)
            mGoogleApiClient.disconnect()
        }
    }
    override fun onConnectionSuspended(p0: Int) { }
    override fun onConnectionFailed(p0: ConnectionResult){
        Log.d(TAG, "OnConnectionFailed")
    }

    override fun onLocationChanged(p0: Location) {
        Log.d(TAG, p0.toString())
        val latLng = LatLng(p0.latitude, p0.longitude)
        if (checkPoints.isNotEmpty()){
            val distance = distanceBetweenLatLng(latLng, checkPoints[0])
            if (distance < 4f && running) {
                checkPoints.removeAt(0)
                if (checkPoints.isEmpty()) {
                    Toast.makeText(
                        this,
                        "Congratulations, you have reached the last location!",
                        Toast.LENGTH_LONG
                    ).show()
                    finishChronometer(chronometer)
                    lastPausePosition = null
                }
            }
        }
        updateCheckPoints(latLng)
    }

    private fun updateCheckPoints(mLoc: LatLng){
        mMap.clear()
        var markerOptions = MarkerOptions()
            .position(mLoc)
            .title("Marker at user's location")
            .icon(iconPerson)
        mMap.addMarker(markerOptions)
        if (checkPoints.isNotEmpty()) {
            markerOptions = MarkerOptions()
                .position(checkPoints[0])
                .title(" first Marker at checkpoint's location")
                .icon(iconActiveCheckPoint)
            mMap.addMarker(markerOptions)
        }
        if (checkPoints.size > 1){
            for (i in 1 until checkPoints.size){
                markerOptions = MarkerOptions()
                    .position(checkPoints[i])
                    .title("${i+1}. Marker at checkpoint's location")
                    .icon(iconPassiveCheckPoint)
                mMap.addMarker(markerOptions)
            }
        }
        if (lastPausePosition != null){
            markerOptions = MarkerOptions()
                .position(lastPausePosition!!)
                .title("Marker at last pause position")
                .icon(iconPause)
            mMap.addMarker(markerOptions)
        }
    }

    @SuppressLint("MissingPermission")
    fun startChronometer(v: View){
        if (!running){
            if (lastPausePosition != null){
                val lastLoc = getFusedLocationProviderClient(this@MapsActivity).lastLocation
                lastLoc.addOnCompleteListener {
                    val latlng = LatLng(it.result.latitude, it.result.longitude)
                    if (distanceBetweenLatLng(latlng, lastPausePosition!!) < 4f){
                        lastPausePosition = null
                        chronometer.base = SystemClock.elapsedRealtime() - pauseOffset
                        chronometer.start()
                        running = true
                        updateCheckPoints(latlng)
                    } else {
                        Toast.makeText(this,
                            "Please, return on your last position, where you take pause",
                            Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                if (checkPoints.isNotEmpty()){
                    chronometer.base = SystemClock.elapsedRealtime() - pauseOffset
                    chronometer.start()
                    running = true
                }
                else{
                    Toast.makeText(this, "Before you start, add at least one checkpoint", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    @SuppressLint("MissingPermission")
    fun pauseChronometer(v: View){
        if (running){
            chronometer.stop()
            pauseOffset = SystemClock.elapsedRealtime() - chronometer.base
            running = false
            val lastLoc = getFusedLocationProviderClient(this@MapsActivity).lastLocation
            lastLoc.addOnCompleteListener {
                val lat = it.result.latitude
                val long = it.result.longitude
                lastPausePosition = LatLng(lat, long)
                updateCheckPoints(lastPausePosition!!)
            }
        }
    }
    fun finishChronometer(v: View){
        pauseOffset = 0
        chronometer.stop()
        running = false
        checkPoints.clear()
        lastPausePosition = null
    }
    fun findFirstCheckPoint(v:View){
        if (checkPoints.isNotEmpty()){
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(checkPoints[0], 17f))
        }
    }
    private fun addCheckPoint(v: View){
        if (modeAddCheckPoint) {
            btnAdd.textSize = 40f
            btnAdd.text = "+"
            modeAddCheckPoint = false
        } else {
            Toast.makeText(this, "Please, touch on map for add checkpoint!", Toast.LENGTH_LONG).show()
            btnAdd.textSize = 20f
            btnAdd.text = "OK"
            modeAddCheckPoint = true
        }
    }
    private fun distanceBetweenLatLng(p1: LatLng, p2: LatLng):Float {
        val p1Loc = Location(p1.toString())
        p1Loc.latitude = p1.latitude
        p1Loc.longitude = p1.longitude

        val p2Loc = Location(p2.toString())
        p2Loc.latitude = p2.latitude
        p2Loc.longitude = p2.longitude

        return p1Loc.distanceTo(p2Loc)
    }
}