Game: orientated run.
Icon: Running Man
Name: Oriented Running

Checkpoints.
At the bottom of the screen there is a panel with buttons and stopwatch.
On the right is a round button with the addition of control points.
When the button is pressed, it is activated by the status of adding control points.
Checkpoints are added to the specified location by clicking on the map.
After clicking the button again, points will not be added.
The first checkpoint (the one you need to get to first) will appear with a green flag.
The rest are shown in red.
When you reach the green flag, the next checkpoint will turn green, and the one you have reached will disappear.
Button.
The "start" button turns on the stopwatch. You can start counting if at least one checkpoint is present on the map.
The "stop" button will stop the countdown, and the map will show the place where the pause was made.
To continue the race, you need to press the start button.
But at the same time, this can only be done if you are in the zone where you paused.
The finish button ends the game and removes all checkpoints.
The resulting time is saved. After restarting by pressing the start button, the time is reset.
P.S.
In the upper right corner there is a button with a green flag. Moves the map to where the green flag is currently.