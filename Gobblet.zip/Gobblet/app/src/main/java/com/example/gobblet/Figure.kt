package com.example.gobblet

import android.graphics.Color

data class Figure(val color: Int, val size: Int)
