package com.example.gobblet

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.text.BoringLayout
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import java.util.*
import kotlin.collections.ArrayList

class GobbletView(context: Context, attr: AttributeSet):
    View(context, attr) {
    private val mPaint: Paint = Paint()
    private var Player = true //Player turn
    private var figureAct: Figure? = null //selected figure to move
        //coordinates of the active shape
    private var actX: Float? = null
    private var actY: Float? = null
        //Figure Sets
    private var whiteFigures = mutableListOf<MutableList<Figure>>()
    private var blackFigures = mutableListOf<MutableList<Figure>>()
        //Board with figures
    private var board = arrayListOf<ArrayList<ArrayList<Figure>>>(
        arrayListOf(arrayListOf(), arrayListOf(), arrayListOf(), arrayListOf()),
        arrayListOf(arrayListOf(), arrayListOf(), arrayListOf(), arrayListOf()),
        arrayListOf(arrayListOf(), arrayListOf(), arrayListOf(), arrayListOf()),
        arrayListOf(arrayListOf(), arrayListOf(), arrayListOf(), arrayListOf())
    )
        //digressions for design
    var tabBoardY = 0f
    private var tabBoardX = 0f
    private var section = 0f
    private var sectionOnBoard = 0f
    private var tab = 0f
    private var height = 0f
    private var width = 0f
        //the place from which the piece was taken (if a wrong move was made, the piece returns to the place from where it was taken)
    private var act_set_row = -1
    private var act_board_col = -1
    private var act_board_row = -1

    private var backColor = Color.argb(255, 44, 252, 218)
    init {
        mPaint.isAntiAlias = true
        mPaint.color = Color.RED
        mPaint.style = Paint.Style.STROKE
        mPaint.strokeJoin = Paint.Join.ROUND
        mPaint.strokeWidth = 4f
        for (i in 0 until 3){
            val row_white = mutableListOf<Figure>()
            val row_black = mutableListOf<Figure>()
            for (j in 1 until 5){
                row_white.add(Figure(Color.WHITE, j))
                row_black.add(Figure(Color.BLACK, j))
            }
            whiteFigures.add(row_white)
            blackFigures.add(row_black)
        }
    }
    fun restart(){
        Player = true
        whiteFigures.clear()
        blackFigures.clear()
        for (i in 0 until 3){
            val row_white = mutableListOf<Figure>()
            val row_black = mutableListOf<Figure>()
            for (j in 1 until 5){
                row_white.add(Figure(Color.WHITE, j))
                row_black.add(Figure(Color.BLACK, j))
            }
            whiteFigures.add(row_white)
            blackFigures.add(row_black)
        }
        for (i in 0 until board.size){
            for (j in 0 until board[i].size){
                board[i][j].clear()
            }
        }
        figureAct = null
        actX = null
        actY = null
        act_set_row = -1
        act_board_col = -1
        act_board_row = -1
        invalidate()
    }
    fun chooseFigureFromSet(x:Float, y:Float){
        val yx = (y / section).toInt()
        if (Player) {
            if ( x < section  && yx < whiteFigures.size && whiteFigures[yx].isNotEmpty()) {
                figureAct = whiteFigures[yx].last()
                actX = x
                actY = y
                whiteFigures[yx].remove(figureAct)
                act_set_row = yx
            }
        } else if (x > width - section && yx < blackFigures.size && blackFigures[yx].isNotEmpty()){
            figureAct = blackFigures[yx].last()
            actX = x
            actY = y
            blackFigures[yx].remove(figureAct)
            act_set_row = yx
        }
    }
    fun chooseFigureFromBoard(x:Float, y:Float){
        val ix = ((y-tabBoardY) / sectionOnBoard).toInt()
        val jx = ((x-tabBoardX) / sectionOnBoard).toInt()
        if (board[ix][jx].isNotEmpty()){
            if (Player) {
                val figure = board[ix][jx].last()
                if (figure.color == Color.WHITE) {
                    figureAct = figure
                    actY = y
                    actX = x
                    board[ix][jx].removeLast()
                    act_board_row = ix
                    act_board_col = jx
                }
            } else {
                val figure = board[ix][jx].last()
                if (figure.color == Color.BLACK){
                    figureAct = figure
                    actY = y
                    actX = x
                    board[ix][jx].removeLast()
                    act_board_row = ix
                    act_board_col = jx
                }
            }
        }
    }
    private fun startTouch(x: Float, y: Float){
        if (x >= tabBoardX &&
            x <= width-tabBoardX &&
            y >= tabBoardY &&
            y <= height-tabBoardY){
            chooseFigureFromBoard(x, y)
        } else chooseFigureFromSet(x, y)
    }
    private fun moveTouch(x: Float, y: Float){
        if (figureAct != null){
            actX = x
            actY = y
        }
    }
    private fun upTouch() {
        if (figureAct != null){
            val x = ((actX!! - tabBoardX)/sectionOnBoard).toInt()
            val y = ((actY!! - tabBoardY)/sectionOnBoard).toInt()
            Log.d("finishX", x.toString())
            Log.d("finishY", y.toString())
            if (legalMove(x, y)){
                board[y][x].add(figureAct!!)
                Player = !Player
                checkEndGame()
            } else {
                if (act_set_row == -1){
                    board[act_board_row][act_board_col].add(figureAct!!)
                } else if (figureAct!!.color == Color.WHITE) {
                   whiteFigures[act_set_row].add(figureAct!!)
                } else if (figureAct!!.color == Color.BLACK){
                    blackFigures[act_set_row].add(figureAct!!)
                }
            }
            figureAct = null
            actX = null
            actY = null
            act_set_row = -1
            act_board_col = -1
            act_board_row = -1
        }
    }
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startTouch(x, y)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                moveTouch(x, y)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                upTouch()
                invalidate()
            }
        }
        return true
    }
    private fun drawBoard(canvas: Canvas){
        for (i in 0 until board.size){
            for (j in 0 until board[i].size){
                mPaint.setColor(backColor)
                mPaint.style = Paint.Style.STROKE
                canvas.drawRect(
                    tabBoardX+j*sectionOnBoard,
                    tabBoardY+i*sectionOnBoard,
                    tabBoardX+(j+1)*sectionOnBoard,
                    tabBoardY+(i+1)*sectionOnBoard, mPaint
                )
                for (k in 0 until board[i][j].size){
                    mPaint.setColor(board[i][j][k].color)
                    mPaint.style = Paint.Style.FILL
                    canvas.drawCircle(
                        tabBoardX+j*sectionOnBoard + sectionOnBoard/2,
                        tabBoardY+i*sectionOnBoard + sectionOnBoard/2,
                        sectionOnBoard/4* board[i][j][k].size/2-5,
                        mPaint)
                }
            }
        }
    }
    private fun drawFigures(canvas: Canvas){
        for (i in 0 until 3) {
//            painting sectors for figures
            mPaint.style = Paint.Style.FILL
            mPaint.setColor(Color.argb(255, 44, 252, 218))
            canvas.drawRoundRect(tab, section*i+tab, section-tab, section*(i+1)-tab, 50f, 50f, mPaint)
            canvas.drawRoundRect(width-section+tab, section*i+tab, width-tab, section*(i+1)-tab, 50f, 50f, mPaint)
            mPaint.setColor(Color.WHITE)
//            painting figures
            for (j in 0 until whiteFigures[i].size){
                val size = whiteFigures[i][j].size
                canvas.drawCircle(section/2, section*i + section/2, ((section-2*tab)/4*size)/2-10, mPaint)
            }
            mPaint.setColor(Color.BLACK)
            for (j in 0 until blackFigures[i].size){
                val size = blackFigures[i][j].size
                canvas.drawCircle(width - section/2, section*i + section/2, ((section-2*tab)/4*size)/2-10, mPaint)
            }
        }
    }
    private fun drawActiveFigure(canvas: Canvas){
        if (actX != null){
            mPaint.setColor(figureAct!!.color)
            canvas.drawCircle(actX!!, actY!!, figureAct!!.size*sectionOnBoard/4/2, mPaint)
        }
    }
    override fun onDraw(canvas: Canvas) {
        height = getHeight().toFloat()
        width = getWidth().toFloat()
        sectionOnBoard = height/4
        section = height/3
        tab = height/30
        tabBoardX = (width - sectionOnBoard*4)/2
        tabBoardY = (height - sectionOnBoard*4)/2
        drawBoard(canvas)
        drawFigures(canvas)
        drawActiveFigure(canvas)
    }
    //check for correctness of the move
    private fun legalMove(x: Int, y: Int): Boolean {
        if (figureAct == null ||
            y >= board.size   ||
            x < 0             ||
            x >= board[y].size) return false
        if (board[y][x].isEmpty()) return true
        val last = board[y][x].last()
        return last.size < figureAct!!.size
    }
    private fun checkEndGame(){
        if (WinCheck(Color.BLACK)) {
            Toast.makeText(context, "Black is Winner!", Toast.LENGTH_LONG).show()
            android.os.Handler().postDelayed({
                restart()},
                1000
            )
        }
        else if (WinCheck(Color.WHITE)){
            Toast.makeText(context, "White is Winner!", Toast.LENGTH_LONG).show()
            android.os.Handler().postDelayed({
                restart()},
                1000
            )
        }
    }
    private fun WinCheck(color: Int): Boolean {
        val cols = getCols()
        val diags = getDiagonals()
        return  board.any { it -> it.all { it.isNotEmpty() && it.last().color == color } } ||
                cols.any { it -> it.all { it.isNotEmpty() && it.last().color == color } } ||
                diags.any { it -> it.all { it.isNotEmpty() && it.last().color == color } }
    }
    //functions return columns and diagonals from the board to check for a winner
    private fun getDiagonals(): Array<ArrayList<ArrayList<Figure>>> {
        val Diagonal1 = arrayListOf<ArrayList<Figure>>()
        val Diagonal2 = arrayListOf<ArrayList<Figure>>()
        var x = 0
        while (x >= 0 && x < board.size && x < board[x].size){
            Diagonal1.add(board[x][x])
            Diagonal2.add(board[x][board[0].size-x-1])
            x++
        }
        return arrayOf(Diagonal1, Diagonal2)
    }
    private fun getCols(): ArrayList<ArrayList<ArrayList<Figure>>> {
        val result = arrayListOf<ArrayList<ArrayList<Figure>>>()
        for (i in 0 until board[0].size) {
            result.add(arrayListOf())
            for (j in 0 until board.size) {
                result[i].add(board[j][i])
            }
        }
        return result
    }
}