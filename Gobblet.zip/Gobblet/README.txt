Hra Gobblet.
Táto hra má všetky pravidlá pôvodnej stolovej hry.
Vo svojom ťahu môžete presunúť figúrku zo sady na hracie pole.
Figúrka môže byť umiestnená na voľnom štvorci alebo na štvorci, kde je horná časť menšia. 
Keď jeden z hráčov vyhrá, je to zvýraznené správou na obrazovke a po sekunde sa hra reštartuje 
(implementuje sa tak, že celé pole sa jednoducho vyčistí, figúrky sa vrátia na svoje miesto a všetky premenné sa vrátia na svoje miesto. pôvodné hodnoty).
V kóde sú tiež zakomentované takmer všetky dodatočné funkcie, napríklad premenné.
Hracie pole je 3-rozmerné pole (stĺpce, riadky a veže figúrok)
Na dotyk obrazovky telefónu, pohyb a ukončenie dotyku sú vytvorené samostatné funkcie. 
Po každom vykonanom ťahu nasleduje kontrola konca hry. Pre tvar bola vytvorená samostatná trieda dátumu, kde je uložená jeho farba a veľkosť. 